# Imbrium

## Released

### 0.1.0

- base library

### 0.1.2

- encoder-decoder predictor support for multistep multivariate time series
